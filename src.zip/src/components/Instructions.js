import React from "react";

export default function Instructions(props){
    return(
        <div style={{paddingLeft:"100px"}}><br/><br/><br/><h1>Form Instructions: </h1><label>Enjoy filling out the form:-)</label></div>
            
    );
}